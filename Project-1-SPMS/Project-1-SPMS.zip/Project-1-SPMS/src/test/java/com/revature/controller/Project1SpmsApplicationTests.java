package com.revature.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1SpmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
