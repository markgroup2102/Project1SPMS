package com.revature.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project1SpmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project1SpmsApplication.class, args);
	}

}
